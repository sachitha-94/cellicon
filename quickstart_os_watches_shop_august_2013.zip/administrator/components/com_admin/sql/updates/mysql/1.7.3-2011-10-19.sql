ALTER TABLE `#__languages` ADD COLUMN `sitename` varchar(1024) NOT NULL AFTER `metadesc`;
